sisi = int(input("Masukkan panjang sisi persegi: "))
luas = sisi * sisi
print("Luas persegi =", luas)
