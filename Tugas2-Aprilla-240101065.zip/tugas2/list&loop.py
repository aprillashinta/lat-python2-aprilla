data = [1, 2, 3, 4, 5]
for i in data:
    hasil = i ** 2
    print("Kuadrat dari", i, "adalah", hasil)
