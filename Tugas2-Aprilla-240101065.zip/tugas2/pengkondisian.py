angka = int(input("Masukkan bilangan: "))
if angka % 2:
    print("Bilangan ini adalah Ganjil")
else:
    print("Bilangan ini adalah Genap")
