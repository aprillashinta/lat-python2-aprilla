for nomor in range(2, 12):
    print("Nomor:", nomor)
